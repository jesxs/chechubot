import tweepy
import time
import random

from keys import *

print('-----------------------------------', flush=True)
print('### CHECHUBOT V1.0 ###')

class StdOutListener(tweepy.StreamListener):
	def on_status(self, status):
		print('tweet recibido de '+status.user.name)

		if status.user.id_str == '2974899033':
				fanbot(status)
				print('* Faving tweet...')

		if '@Depbot_' in status.text and status.user.id_str != '1088169100789067777':
			
			if '#añade' in status.text:
				addToArray(status)

			if '#meteme' in status.text:
				addUser(status)
			
	def on_error(self, status):
		print(status)

def fanbot(tweet):
	api.create_favorite(tweet.id)

def addToArray(tweet):
	tweetRaw = tweet.text.replace('@Depbot_','')
	tweetId = tweet.id
	tweetText = tweetRaw.replace('#añade','')
	tweetText = tweetText[2:]

	with open("tweets.txt", "a") as myfile:
		myfile.write(tweetText+'\n')
	
	if not tweet.user.id_str == '2974899033':
		api.create_favorite(tweet.id)

	print('* Added tweet: '+tweetText)
	api.update_status("Añadido tonto @"+tweet.user.screen_name, in_reply_to_status_id = tweetId)

def addUser(tweet):
	userToAdd = tweet.user.screen_name
	tweetId = tweet.id

	people = tuple(open('people.txt', 'r'))
	
	if userToAdd+'\n' not in people:

		with open("people.txt", "a") as myfile:
			myfile.write(userToAdd+'\n')
			api.update_status("Te he metido satisfactoriamente @"+userToAdd, in_reply_to_status_id = tweetId)

			print('* Added user: '+userToAdd)
	else:
		api.update_status("Ya estas metido subnormal @"+userToAdd, in_reply_to_status_id = tweetId)
		print('* User already in, not added: '+userToAdd)

	print(people)
	
auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_KEY, ACCESS_SECRET)
api = tweepy.API(auth)

listener = StdOutListener()

stream = tweepy.Stream(auth, listener)

stream.filter(track=['@Depbot_','#añade'],follow=['2974899033'],is_async=True)

#in minutes
intervals = 1


def publishTweets():
	tweets = tuple(open('tweets.txt', 'r'))

	people = tuple(open('people.txt', 'r'))

	while True:	
		try:
			tweetNum = random.randint(1,len(tweets))
			str(tweetNum)
			print('# Took tweet number '+str(tweetNum)+' , "'+tweets[tweetNum]+'"')

			print(tweetNum)

			str(tweetNum)
			if '{}' in tweets[tweetNum]:
				actualTweet = tweets[tweetNum]

				person1 = people[random.randint(0,len(people) - 1)]
				person2 = people[random.randint(0,len(people) - 1)]
				print('# Chose '+person1+' and '+person2)

				tweetCombo = actualTweet.format('@'+person1, '@'+person2)

				print(tweetCombo)
				api.update_status(tweetCombo)
				print('# Tweeting...')
				
			else:
				api.update_status(tweets[tweetNum])
				print('# Tweeting...')
				print('---------------------------------')


			time.sleep(intervals * 60)

		except:
			print('# Tweet was a duplicate, choosing another one...')
			tweetNum = random.randint(1,len(tweets))
			str(tweetNum)
			print('# Took tweet number '+str(tweetNum)+' , "'+tweets[tweetNum]+'"')

			print(tweetNum)

			str(tweetNum)
			if '{}' in tweets[tweetNum]:
				actualTweet = tweets[tweetNum]

				person1 = people[random.randint(0,len(people) - 1)]
				person2 = people[random.randint(0,len(people) - 1)]
				print('# Chose '+person1+' and '+person2)

				tweetCombo = actualTweet.format('@'+person1, '@'+person2)

				print(tweetCombo)
				api.update_status(tweetCombo)
				print('# Tweeting...')
				print('---------------------------------')
				
			else:
				api.update_status(tweets[tweetNum])
				print('# Tweeting...')

			time.sleep(intervals * 60)

publishTweets()


